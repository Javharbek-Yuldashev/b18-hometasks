import { Component } from "react";
import Tasbih from "./projects/tasbih-app/tasbih";

class App extends Component {
  render() {
    return <Tasbih />;
  }
}

export default App;
