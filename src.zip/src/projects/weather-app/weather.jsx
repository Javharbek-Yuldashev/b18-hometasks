import { Component } from "react";

class Weather extends Component {
  render() {
    return <h1>Weather Component</h1>;
  }
}

export default Weather;
